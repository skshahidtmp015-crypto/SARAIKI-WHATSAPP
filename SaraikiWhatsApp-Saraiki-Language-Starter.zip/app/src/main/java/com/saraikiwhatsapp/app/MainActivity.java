package com.saraikiwhatsapp.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int green = Color.rgb(18, 140, 75);
    private final int dark = Color.rgb(7, 94, 52);
    private LinearLayout root;
    private String userName = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showWelcome();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        return b;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(24, 20, 24, 20);
        l.setBackgroundColor(Color.WHITE);
        return l;
    }

    private void setRoot(View v) { setContentView(v); }

    private void showWelcome() {
        root = column();
        root.setGravity(Gravity.CENTER);
        TextView logo = text("●", 58, green, true);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, 72));
        TextView title = text("Saraiki WhatsApp", 28, dark, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = text("اپݨیاں نال رابطہ رکھو 💚", 16, Color.DKGRAY, false);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        addSpace(root, 28);
        EditText name = new EditText(this);
        name.setHint("تہاݙا ناں");
        name.setSingleLine(true);
        root.addView(name, new LinearLayout.LayoutParams(-1, 56));
        EditText email = new EditText(this);
        email.setHint("ای میل پتہ");
        email.setInputType(33);
        root.addView(email, new LinearLayout.LayoutParams(-1, 56));
        EditText password = new EditText(this);
        password.setHint("پاس ورڈ");
        password.setInputType(129);
        root.addView(password, new LinearLayout.LayoutParams(-1, 56));
        addSpace(root, 16);
        Button enter = button("اڳوں ون٘دے رہو");
        root.addView(enter, new LinearLayout.LayoutParams(-1, 54));
        TextView note = text("ایہہ آزمائشی ورژن ہے۔ اصلی لاگ اِن تے چیٹ واسطے Firebase جوڑݨا پوسی۔", 13, Color.GRAY, false);
        note.setGravity(Gravity.CENTER);
        root.addView(note);
        enter.setOnClickListener(v -> {
            userName = name.getText().toString().trim();
            if (userName.isEmpty()) userName = "Dost";
            showChats();
        });
        setRoot(root);
    }

    private void showChats() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(20, 18, 20, 18);
        header.setBackgroundColor(green);
        TextView title = text("Saraiki WhatsApp", 24, Color.WHITE, true);
        header.addView(title);
        TextView hello = text("سلام، " + userName + " 👋", 14, Color.WHITE, false);
        header.addView(hello);
        root.addView(header);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(12, 8, 12, 8);
        tabs.setBackgroundColor(dark);
        TextView chats = text("چیٹاں", 14, Color.WHITE, true);
        TextView status = text("سٹیٹس", 14, Color.WHITE, true);
        TextView calls = text("کالاں", 14, Color.WHITE, true);
        chats.setGravity(Gravity.CENTER);
        status.setGravity(Gravity.CENTER);
        calls.setGravity(Gravity.CENTER);
        tabs.addView(chats, new LinearLayout.LayoutParams(0, 42, 1));
        tabs.addView(status, new LinearLayout.LayoutParams(0, 42, 1));
        tabs.addView(calls, new LinearLayout.LayoutParams(0, 42, 1));
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(16, 8, 16, 8);
        addChatRow(list, "🌿", "سرائیکی برادری", "سرائیکی واٹس ایپ وچ جی آیاں نوں!", "Demo");
        addChatRow(list, "🟢", "تہاݙا دوست", "السلام علیکم!", "Demo");
        addChatRow(list, "👥", "گھر دا گروپ", "گروپ چیٹ", "Demo");
        addChatRow(list, "💬", "نویں گل بات", "چیٹ کھولݨ واسطے دباؤ", "Demo");
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Button newChat = button("+ نویں چیٹ");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 54);
        bp.setMargins(16, 8, 16, 16);
        root.addView(newChat, bp);
        newChat.setOnClickListener(v -> showConversation("نویں گل بات"));
        setRoot(root);
    }

    private void addChatRow(LinearLayout list, String emoji, String name, String message, String time) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(4, 14, 4, 14);
        TextView avatar = text(emoji, 26, green, true);
        avatar.setGravity(Gravity.CENTER);
        row.addView(avatar, new LinearLayout.LayoutParams(54, 54));
        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        TextView n = text(name, 17, Color.BLACK, true);
        TextView m = text(message, 13, Color.DKGRAY, false);
        details.addView(n);
        details.addView(m);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, -2, 1);
        dp.setMargins(8, 0, 0, 0);
        row.addView(details, dp);
        row.addView(text(time, 11, Color.GRAY, false));
        list.addView(row);
        View line = new View(this);
        line.setBackgroundColor(Color.rgb(235, 235, 235));
        list.addView(line, new LinearLayout.LayoutParams(-1, 1));
        row.setOnClickListener(v -> showConversation(name));
    }

    private void showConversation(String person) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(238, 245, 239));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(12, 12, 12, 12);
        header.setBackgroundColor(green);
        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        header.addView(back, new LinearLayout.LayoutParams(48, 48));
        TextView personTitle = text(person, 19, Color.WHITE, true);
        header.addView(personTitle);
        page.addView(header);
        back.setOnClickListener(v -> showChats());

        ScrollView scroll = new ScrollView(this);
        LinearLayout messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(14, 16, 14, 16);
        addBubble(messages, "سلام! سرائیکی واٹس ایپ وچ جی آیاں نوں۔", false);
        addBubble(messages, "ایہہ آزمائشی چیٹ سکرین ہے۔", false);
        scroll.addView(messages);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = new LinearLayout(this);
        composer.setPadding(8, 8, 8, 8);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setBackgroundColor(Color.WHITE);
        EditText input = new EditText(this);
        input.setHint("سنیہا لکھو...");
        input.setSingleLine(true);
        composer.addView(input, new LinearLayout.LayoutParams(0, 52, 1));
        Button send = button("پٹھاؤ");
        composer.addView(send);
        page.addView(composer);
        send.setOnClickListener(v -> {
            String msg = input.getText().toString().trim();
            if (!msg.isEmpty()) {
                addBubble(messages, msg, true);
                input.setText("");
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
                Toast.makeText(this, "ایہہ آزمائشی سنیہا ہے؛ اصلی چیٹ واسطے Firebase جوڑݨا باقی ہے۔", Toast.LENGTH_SHORT).show();
            }
        });
        setRoot(page);
    }

    private void addBubble(LinearLayout messages, String value, boolean mine) {
        TextView bubble = text(value, 15, Color.BLACK, false);
        bubble.setPadding(14, 10, 14, 10);
        bubble.setBackgroundTintList(null);
        bubble.setBackgroundColor(mine ? Color.rgb(210, 245, 202) : Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(mine ? 52 : 0, 5, mine ? 0 : 52, 5);
        bubble.setLayoutParams(p);
        messages.addView(bubble);
    }

    private void addSpace(LinearLayout layout, int height) {
        View spacer = new View(this);
        layout.addView(spacer, new LinearLayout.LayoutParams(1, height));
    }
}
