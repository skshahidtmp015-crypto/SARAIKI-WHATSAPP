# Saraiki WhatsApp — Android starter project

This is a starter Android app project designed to be built from a phone using GitHub Actions (free tier availability/limits may change).

## Language
- User-facing app screens are localized in Saraiki (Urdu/Arabic script).

## What is included
- Native Android app shell with Saraiki WhatsApp branding
- Login / registration screen UI
- Chat list and conversation UI demo
- Firebase Authentication + Realtime Database wiring placeholders
- GitHub Actions workflow to build a debug APK in the cloud

## Important
This starter project is NOT yet a production-ready WhatsApp replacement. The screens work as a demo, but real multi-user chat requires Firebase setup, database security rules, and testing. Voice/video calls, end-to-end encryption, media uploads, push notifications, and group administration are not implemented.

## Build from your Android phone
1. Create a free GitHub account at https://github.com if you don't have one.
2. Create a new repository and upload the contents of this ZIP (not the ZIP itself).
3. In the repository, open **Actions** and enable workflows if asked.
4. Open the **Actions** tab, choose **Build Saraiki WhatsApp APK**, then tap **Run workflow**.
5. When it finishes, open the run and download the `SaraikiWhatsApp-debug-apk` artifact.
6. Extract the downloaded artifact ZIP on your phone and install the APK. Android may ask you to allow installs from your browser/file manager.

## Connect Firebase for real accounts and chat
1. Go to https://console.firebase.google.com and create a project.
2. Add an Android app with package name `com.saraikiwhatsapp.app`.
3. Download `google-services.json` and put it in the `app/` folder.
4. In Firebase Console, enable **Authentication > Sign-in method > Email/Password**.
5. Create a **Realtime Database** and start in locked/production mode. Do not use public read/write rules.
6. Add proper per-user security rules before real users use the app.
7. This starter's Firebase configuration is a placeholder. Authentication and database operations must be completed and tested before treating it as a real chat service.

## Build notes
- Uses Android Gradle Plugin and Gradle wrapper download by GitHub Actions.
- Debug APK is for testing. Do not distribute as a secure production app without completing security, privacy, and release-signing work.
